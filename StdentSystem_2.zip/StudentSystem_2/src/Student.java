class Student {
    private static int nextID = 1;
    private int studentID;
    private String studentName;
    private String studentAddress;
    private String studentContact;
    private String studentSubject;
    private String studentTeacher;

    public Student(String studentName, String studentAddress,
                   String studentContact, String studentSubject, String studentTeacher) {
        this.studentID = nextID++;
        this.studentName = studentName;
        this.studentAddress = studentAddress;
        this.studentContact = studentContact;
        this.studentSubject = studentSubject;
        this.studentTeacher = studentTeacher;
    }


    public String toString() {
        return "Student ID: " + studentID +
                "\nName: " + studentName +
                "\nAddress: " + studentAddress +
                "\nContact: " + studentContact +
                "\nSubject: " + studentSubject +
                "\nTeacher: " + studentTeacher;
    }

    public String getStudentName() {
        return studentName;
    }

    public int getStudentID() {
        return studentID;
    }

    public String getStudentSubject() {
        return studentSubject;
    }

    public String getStudentTeacher() {
        return studentTeacher;
    }
}
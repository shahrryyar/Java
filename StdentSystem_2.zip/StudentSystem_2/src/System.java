
import java.util.ArrayList;
import javax.swing.JOptionPane;

class System {
    private ArrayList<Student> students;

    public System() {
        this.students = new ArrayList();
    }

    public void addStudent(Student student) {
        students.add(student);
        JOptionPane.showMessageDialog(null, "Student added successfully. Student ID: " + student.getStudentID());
    }

    public void removeStudent(String name) {
        Student studentToRemove = null;
        for (Student student : students) {
            if (student.getStudentName().equalsIgnoreCase(name)) {
                studentToRemove = student;
                break;
            }
        }

        if (studentToRemove != null) {
            students.remove(studentToRemove);
            JOptionPane.showMessageDialog(null, "Student '" + name + "' removed successfully.");
        } else {
            JOptionPane.showMessageDialog(null, "Student with name '" + name + "' not found. Unable to remove.");
        }
    }

    public void displayAllStudents() {
        StringBuilder allStudents = new StringBuilder();
        for (Student student : students) {
            allStudents.append(student).append("\n------------------------\n");
        }
        JOptionPane.showMessageDialog(null, "All Students:\n" + allStudents);
    }

    public void searchStudentByName(String name) {
        boolean found = false;
        StringBuilder result = new StringBuilder();
        for (Student student : students) {
            if (student.getStudentName().equalsIgnoreCase(name)) {
                result.append("Student found:\n").append(student).append("\n");
                found = true;
                break;
            }
        }
        if (!found) {
            JOptionPane.showMessageDialog(null, "Student with name '" + name + "' not found.");
        } else {
            JOptionPane.showMessageDialog(null, result.toString());
        }
    }

    public void searchStudentBySubject(String subject) {
        StringBuilder result = new StringBuilder();
        boolean found = false;
        for (Student student : students) {
            if (student.getStudentSubject().equalsIgnoreCase(subject)) {
                result.append("Student Name: ").append(student.getStudentName()).append("\n");
                found = true;
            }
        }
        if (found) {
            JOptionPane.showMessageDialog(null, "Students with subject '" + subject + "':\n" + result.toString());
        } else {
            JOptionPane.showMessageDialog(null, "No students found with subject '" + subject + "'.");
        }
    }

    public void searchStudentByTeacher(String teacher) {
        StringBuilder result = new StringBuilder();
        boolean found = false;
        for (Student student : students) {
            if (student.getStudentTeacher().equalsIgnoreCase(teacher)) {
                result.append("Student Name: ").append(student.getStudentName()).append("\n");
                found = true;
            }
        }
        if (found) {
            JOptionPane.showMessageDialog(null, "Students with teacher '" + teacher + "':\n" + result.toString());
        } else {
            JOptionPane.showMessageDialog(null, "No students found with teacher '" + teacher + "'.");
        }
    }
}
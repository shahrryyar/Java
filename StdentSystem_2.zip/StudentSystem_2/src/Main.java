
import javax.swing.JOptionPane;

public class Main {
    public static void main(String[] args) {
        System system = new System();

        int choice;
        do {
            String input = JOptionPane.showInputDialog(
                    "Menu:\n" +
                            "1. Add Student\n" +
                            "2. Remove Student\n" +
                            "3. Display All Students\n" +
                            "4. Search Student by Name\n" +
                            "5. Search Students by Subject\n" +
                            "6. Search Students by Teacher\n" +
                            "7. Exit\n" +
                            "Enter your choice:");

            
                choice = Integer.parseInt(input);

                switch (choice) {
                    case 1:
                        // zyad krdny talaba
                        String StudentName = JOptionPane.showInputDialog("Enter Student Name:");
                        String StudentAddress = JOptionPane.showInputDialog("Enter Student Address:");
                        String StudentContact = JOptionPane.showInputDialog("Enter Student Contact:");
                        String StudentSubject = JOptionPane.showInputDialog("Enter Student Subject:");
                        String StudentTeacher = JOptionPane.showInputDialog("Enter Student Teacher:");

                        system.addStudent(new Student(StudentName,
                                StudentAddress, StudentContact, StudentSubject, StudentTeacher));
                        break;

                    case 2:
                        
                        String removeName = JOptionPane.showInputDialog("Enter the name of the student you want to remove:");
                        system.removeStudent(removeName);
                        break;

                    case 3:
                      
                        system.displayAllStudents();
                        break;

                    case 4:
                     
                        String searchName = JOptionPane.showInputDialog("Enter the name of the student you want to search:");
                        system.searchStudentByName(searchName);
                        break;

                    case 5:
                     
                        String searchSubject = JOptionPane.showInputDialog("Enter the subject to search for:");
                        system.searchStudentBySubject(searchSubject);
                        break;

                    case 6:
                        
                        String searchTeacher = JOptionPane.showInputDialog("Enter the teacher to search for:");
                        system.searchStudentByTeacher(searchTeacher);
                        break;

                    case 7:
                        JOptionPane.showMessageDialog(null, "Exiting the program. Goodbye!");
                        break;

                    default:
                        JOptionPane.showMessageDialog(null, "Invalid choice. Please enter a valid option.");
                }
             
        } while (choice != 7);
    }
}